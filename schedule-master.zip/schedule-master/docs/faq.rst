.. At some point we'll want to migrate FAQ.rst to the docs folder but to
.. breaking links on PyPI we need to leave it there until we prepare the
.. next schedule release

.. include:: ../FAQ.rst
